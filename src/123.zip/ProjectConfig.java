package org.example;

//import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Primary;

@Configuration
@ComponentScan(basePackages = "org.example")
public class ProjectConfig {

//    @Bean
//    @Primary
//    Parrot parrot() {
//        Parrot parrot = new Parrot();
//        parrot.setName("Parrot");
//        return parrot;
//    }
//    @Bean
//    Integer ten() {
//        return 10;
//    }
//
//    @Bean
//    Parrot parrot2() {
//        Parrot parrot = new Parrot();
//        parrot.setName("Parrot2");
//        return parrot;
//    }
}
