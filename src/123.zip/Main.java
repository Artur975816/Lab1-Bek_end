package org.example;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
    var context = new AnnotationConfigApplicationContext(ProjectConfig.class);
//    Parrot parrot = context.getBean(Parrot.class);
//    parrot.setName("Parrot");
//    System.out.println(parrot.getName());

        Person person = context.getBean(Person.class);

        System.out.println("Person's name: " + person.getName());
        System.out.println("Person's parrot: " + person.getParrot().getName());
//
//    Integer n = context.getBean("ten", Integer.class);
//    System.out.println(n);
//
//    Parrot parot2 = context.getBean("parrot2",Parrot.class);
//    System.out.println(parot2.getName());


    }
}